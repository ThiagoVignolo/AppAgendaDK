package es.ieslosmontecillos;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.net.URL;
import java.util.ResourceBundle;

public class AgendaViewController implements Initializable {

    public TableView tableViewAgenda;
    public TableColumn columnNombre;
    public TableColumn columnApellido;
    public TableColumn columnEmail;
    private DataUtil dataUtil;
    private ObservableList<Provincia> olProvincias =
            FXCollections.observableArrayList();
    private ObservableList<Persona> olPersonas =
            FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void setDataUtil(DataUtil dataUtil) {
        this.dataUtil = dataUtil;
    }

    public void setOlProvincias(ObservableList<Provincia> olProvincias) {
        this.olProvincias = olProvincias;
    }

    public void setOlPersonas(ObservableList<Persona> olPersonas) {
        this.olPersonas = olPersonas;
    }



    public void cargarTodasPersonas() {
        tableViewAgenda.setItems(FXCollections.observableArrayList(olPersonas));
    }

}